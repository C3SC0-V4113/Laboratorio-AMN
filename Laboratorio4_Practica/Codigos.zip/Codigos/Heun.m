function M=Heun(a,b,h,ci,f,ed,ya)
syms t y
n=int32((b-a)/(h));
ti=a:h:b;
fexacta = dsolve(ed,ya);
exacta=double(subs(fexacta,t,ti));
wi(1)=ci;
for i=1:n
    wi(i+1)=wi(i)+h/4*(subs(f,[t,y],[ti(i),wi(i)]))+(3*h)/4*(subs(f,[t,y],[ti(i)+(2*h)/3,wi(i)+(2*h)/3*(subs(f,[t,y],[ti(i),wi(i)]))]));
end
fprintf('        ti                  wi             exacta ');
fprintf('\n');
M=[ti' wi' exacta'];